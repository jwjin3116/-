import pandas
#pandas 사용
data=pandas.read_csv('한국전력거래소_시간별 전국 전력수요량_20241231.csv',encoding='euc-kr')
#시간별 전력수요량 데이터 읽기
data_only = data.iloc[:, 1:]
#필요한 데이터만 거르기
sum_list=data_only.sum(axis=1).tolist()
sum_list2=data_only.sum(axis=0).tolist()
#데이터를 리스트로 바꾸기+행합 열합
summer=sum(sum_list[152:244])/92
winter=sum(sum_list[335:366]+sum_list[0:60])/91
year=sum(sum_list[0:366])/366
summer
winter
year
#여름,겨울, 연간 전력 소비 하루당 평균
sum_sorted=sorted(sum_list)
christmas=sum_sorted.index(sum_list[359])
christmas
#크리스마스의 1년 중 전력 소모량 등수(0~365,클수록 전력 소모량 많음)
for i in range(9):
    a=sum_list.index(sum_sorted[365-i])
    print(a)
#가장 많이 전력 소비한 날 10일
ranking=[]
sum_sorted2=sorted(sum_list2)
for i in range(23):
    ranking.append(sum_sorted2.index(sum_list2[i]))
print(ranking)
#가장 전력 많이 쓰는 하루중 시간대 순위

excel=pandas.read_excel('8.시군구별 전력사용량(홈페이지 게시용)_202405.xlsx',engine='openpyxl')
#시군구별 전력사용량 데이터 읽기
data = excel.iloc[1:].reset_index(drop=True)
data.columns = data.iloc[0]
data = data[1:].reset_index(drop=True)
#특정 행을 제목으로 정함과 쓸모없는 행 제거
data['합계'] = data.iloc[:, 4:9].sum(axis=1)
#1~5월 전력소비량을 모두 더한 "합계"열 제작
seoul_farming_data=data[(data.iloc[:,3]=='농사용')&(data.iloc[:,1]=='서울특별시')]
kyeongi_farming_data=data[(data.iloc[:,3]=='농사용')&(data.iloc[:,1]=='경기도')]
farming_data=data[(data.iloc[:,3]=='농사용')]
seoul_farming_data['합계'].sum()
kyeongi_farming_data['합계'].sum()
farming_data['합계'].sum
#서울, 경기, 전국의 농사용 전력 소비량
seoul_streetlight_data=data[(data.iloc[:,3]=='가로등')&(data.iloc[:,1]=='서울특별시')]
kyeongi_streetlight_data=data[(data.iloc[:,3]=='가로등')&(data.iloc[:,1]=='경기도')]
streetlight_data=data[(data.iloc[:,3]=='가로등')]
seoul_streetlight_data['합계'].sum()
kyeongi_streetlight_data['합계'].sum()
streetlight_data['합계'].sum()
#서울, 경기, 전국의 가로등 전력 소비량
jeju_sum_data=data[(data.iloc[:,1]=='제주특별자치도')&(data.iloc[:,3]=='합 계')]
notjeju_sum_data=data[(data.iloc[:,1]!='제주특별자치도')&(data.iloc[:,3]=='합 계')]
jeju_sum_data['합계'].sum()
notjeju_sum_data['합계'].sum()
#제주, 나머지의 모든 전력 소비량
